import os
import re

# Path to your main folder
main_folder = os.getcwd()

# Path to strings.q
strings_file = os.path.join(main_folder, "strings.q")

# Step 1: Read variable-to-string mapping from strings.q
mapping = {}
with open(strings_file, "r", encoding="utf-8") as f:
    for line in f:
        # Skip empty lines
        line = line.strip()
        if not line or "=" not in line:
            continue
        
        # Match pattern: variable = "string"
        match = re.match(r'(\w+)\s*=\s*"(.+)"', line)
        if match:
            var, string_value = match.groups()
            mapping[string_value] = var

# Step 2: Recursively process all .q files except strings.q
for root, dirs, files in os.walk(main_folder):
    for file in files:
        if file.endswith(".q") and file != "strings.q":
            file_path = os.path.join(root, file)
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()

            # Step 3: Replace strings with variables
            for string_value, var in mapping.items():
                # Escape string for regex
                escaped_string = re.escape(string_value)
                # Replace with variable including quotes
                globalVar = "$" + var
                content = re.sub(f'"{escaped_string}"', globalVar, content)

            # Step 4: Write changes back to file
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)

print("Replacement complete!")